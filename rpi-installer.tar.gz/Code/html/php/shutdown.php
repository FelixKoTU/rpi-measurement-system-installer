<?php exec("/sbin/shutdown -h now"); ?>
