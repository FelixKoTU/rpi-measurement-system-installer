<?php
exec("/sbin/shutdown -r now");
?>
