# Raspberry Pi installer
This release handles all the necessary packages and configurations for the measurement system.

Run the following file to >do something with sudo<:
```sh
sudo sh installer.sh
```

Run the following file to >do something without sudo<:
```sh
./dummy.sh
```
