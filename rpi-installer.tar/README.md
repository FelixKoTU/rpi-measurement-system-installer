# Rapsberry Pi installer
This release handles all the necessary packages and configurations for the measurement system.

Run the following files with:
```sh
sudo sh installer.sh
./dummy.sh
```
