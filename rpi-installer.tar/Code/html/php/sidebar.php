<?php
echo 
'<div class="sidenav">

	<a href="index.html"> Home</a>
	<a href="clients.html"> Clients</a>
	<button class="dropdown-btn"> Logs
		<i class="fa fa-caret-down"></i>
  	</button>

	<div class="dropdown-container">
  		<a href="log1.html"> Xiaomi Data</a>
<!--    	<a href="#"> Link 2</a> -->
  	</div>
<!-- 	<a href="settings.html"> Settings</a> -->
<!-- 	<a href="form.html"> Form</a> -->
<!--	<a href="mail.html"> Send Mail</a> -->
	<a href="php/restart.php"> Restart</a>
	<a href="php/shutdown.php"> Shutdown</a>
</div>';
?>
